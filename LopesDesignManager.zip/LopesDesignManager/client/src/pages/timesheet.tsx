import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Plus, Clock, Loader2, Calendar } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { TimesheetEntry, Task, Project } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/contexts/AuthContext";

export default function Timesheet() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    descricao: "",
    horasTrabalhadas: "",
    taskId: "",
    projectId: "",
    data: new Date().toISOString().split("T")[0],
  });

  const { data: entries, isLoading } = useQuery<TimesheetEntry[]>({
    queryKey: ["/api/timesheet"],
  });

  const { data: tasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: projects } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/timesheet", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/timesheet"] });
      toast({ title: "Registro de tempo salvo com sucesso!" });
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao salvar registro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      descricao: "",
      horasTrabalhadas: "",
      taskId: "",
      projectId: "",
      data: new Date().toISOString().split("T")[0],
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const myEntries = entries?.filter((entry) => entry.userId === user?.id);
  const totalHoras = myEntries?.reduce((acc, entry) => acc + Number(entry.horasTrabalhadas), 0) || 0;

  const getTaskTitle = (id: string | null) => tasks?.find((t) => t.id === id)?.titulo || "-";
  const getProjectTitle = (id: string | null) => projects?.find((p) => p.id === id)?.titulo || "-";

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent">
            Timesheet
          </h1>
          <p className="text-muted-foreground mt-1">Controle de horas trabalhadas</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button data-testid="button-novo-registro">
              <Plus className="mr-2 h-4 w-4" />
              Registrar Tempo
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registrar Tempo</DialogTitle>
              <DialogDescription>
                Registre as horas trabalhadas em uma tarefa ou projeto
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição *</Label>
                <Input
                  id="descricao"
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  placeholder="O que você fez?"
                  required
                  data-testid="input-descricao"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="horasTrabalhadas">Horas Trabalhadas *</Label>
                <Input
                  id="horasTrabalhadas"
                  type="number"
                  step="0.25"
                  value={formData.horasTrabalhadas}
                  onChange={(e) => setFormData({ ...formData, horasTrabalhadas: e.target.value })}
                  placeholder="Ex: 2.5"
                  required
                  data-testid="input-horas"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="taskId">Tarefa (opcional)</Label>
                <Select value={formData.taskId} onValueChange={(value) => setFormData({ ...formData, taskId: value })}>
                  <SelectTrigger data-testid="select-tarefa">
                    <SelectValue placeholder="Selecione uma tarefa" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Nenhuma</SelectItem>
                    {tasks?.filter((t) => t.assignedToId === user?.id).map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.titulo}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="projectId">Projeto (opcional)</Label>
                <Select value={formData.projectId} onValueChange={(value) => setFormData({ ...formData, projectId: value })}>
                  <SelectTrigger data-testid="select-projeto">
                    <SelectValue placeholder="Selecione um projeto" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Nenhum</SelectItem>
                    {projects?.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.titulo}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="data">Data *</Label>
                <Input
                  id="data"
                  type="date"
                  value={formData.data}
                  onChange={(e) => setFormData({ ...formData, data: e.target.value })}
                  required
                  data-testid="input-data"
                />
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createMutation.isPending} data-testid="button-salvar-registro">
                  {createMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    "Salvar"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="hover-elevate">
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total de Horas (Mês Atual)</CardTitle>
          <div className="p-2 rounded-lg bg-gradient-to-br from-chart-2 to-chart-2/80">
            <Clock className="h-5 w-5 text-white" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold" data-testid="text-total-horas">
            {totalHoras.toFixed(2)}h
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Histórico de Registros</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Tarefa</TableHead>
                  <TableHead>Projeto</TableHead>
                  <TableHead className="text-right">Horas</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {myEntries && myEntries.length > 0 ? (
                  myEntries
                    .sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime())
                    .map((entry) => (
                      <TableRow key={entry.id} data-testid={`row-registro-${entry.id}`}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            {new Date(entry.data).toLocaleDateString("pt-BR")}
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">{entry.descricao}</TableCell>
                        <TableCell>{getTaskTitle(entry.taskId)}</TableCell>
                        <TableCell>{getProjectTitle(entry.projectId)}</TableCell>
                        <TableCell className="text-right font-semibold">
                          {Number(entry.horasTrabalhadas).toFixed(2)}h
                        </TableCell>
                      </TableRow>
                    ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                      Nenhum registro de tempo encontrado
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
