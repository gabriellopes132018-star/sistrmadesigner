# Lopes Designer Gestão

Sistema completo de gestão para agências de design com controle de projetos, clientes, finanças, tarefas e chat interno em tempo real.

## 🎨 Características Principais

### Autenticação e Permissões
- **3 Níveis de Acesso**: Admin, Gerente e Funcionário
- Autenticação JWT com bcrypt
- Permissões baseadas em roles

### Gestão de Clientes
- CRUD completo de clientes
- Informações: nome, e-mail, telefone, empresa
- Associação automática com projetos

### Gestão de Projetos
- Títulos, descrições e valores
- Status: Não Iniciado, Em Andamento, Concluído
- Upload de arquivos (PSD, AI, PNG, etc)
- Datas de início e prazo
- Responsável e cliente associados

### Sistema de Tarefas
- Atribuição de tarefas para funcionários
- Admin e Gerente criam tarefas
- Funcionários marcam como concluídas
- Associação opcional com projetos

### Controle Financeiro
- Fluxo de caixa completo
- Receitas e despesas
- Categorização
- Relatórios visuais

### Timesheet
- Registro de horas trabalhadas
- Associação com tarefas e projetos
- Relatórios de produtividade

### Chat Interno
- Comunicação em tempo real via WebSocket
- Histórico de mensagens
- Notificações instantâneas

### Avisos e Notificações
- Sistema de comunicados internos
- Segmentação por função (Admin, Gerente, Funcionário)
- Timeline de avisos

### Dashboard
- Gráficos de faturamento
- Status de projetos
- Horas trabalhadas por funcionário
- Receitas vs Despesas

### Design
- Tema claro e escuro
- Paleta de cores: Azul claro, Azul escuro, Roxo e Rosa
- Totalmente responsivo
- Interface moderna e intuitiva

## 🚀 Tecnologias

### Frontend
- React 18
- TailwindCSS
- Shadcn UI
- TanStack Query
- Wouter (roteamento)
- Recharts (gráficos)
- WebSocket (chat)

### Backend
- Node.js + Express
- PostgreSQL (Neon)
- Drizzle ORM
- JWT + Bcrypt
- Multer (upload de arquivos)
- WebSocket (ws)

## 📦 Como Rodar no Replit

1. O sistema já está configurado e rodando
2. Acesse a aplicação através do preview do Replit
3. Credenciais de teste:
   - **Admin**: `admin` / `admin123`
   - **Gerente**: `gerente` / `admin123`
   - **Funcionário**: `funcionario` / `admin123`

## 🔧 Comandos Disponíveis

```bash
# Instalar dependências
npm install

# Rodar em desenvolvimento
npm run dev

# Sincronizar schema do banco de dados
npm run db:push

# Forçar sincronização (se houver conflitos)
npm run db:push --force
```

## 🌐 Deploy em Produção

### Opção 1: Render + Vercel

**Backend (Render):**
1. Faça fork do repositório
2. Crie uma conta no [Render](https://render.com)
3. Crie um novo Web Service conectando ao repositório
4. Configure as variáveis de ambiente:
   - `DATABASE_URL`: String de conexão PostgreSQL
   - `JWT_SECRET`: Chave secreta para JWT
   - `NODE_ENV`: production
5. Comando de build: `npm install`
6. Comando de start: `npm run dev`

**Frontend (Vercel):**
1. Faça fork do repositório
2. Crie uma conta no [Vercel](https://vercel.com)
3. Importe o projeto
4. Configure build settings:
   - Build Command: `npm run build`
   - Output Directory: `dist`
5. Configure variável de ambiente:
   - `VITE_API_URL`: URL do backend no Render

### Opção 2: Railway

1. Crie uma conta no [Railway](https://railway.app)
2. Crie um novo projeto e conecte ao repositório
3. Railway detectará automaticamente a configuração
4. Configure as variáveis de ambiente:
   - `DATABASE_URL`: Crie um banco PostgreSQL no Railway
   - `JWT_SECRET`: Chave secreta para JWT
   - `NODE_ENV`: production
5. Deploy automático a cada push

### Opção 3: DigitalOcean App Platform

1. Crie uma conta no [DigitalOcean](https://www.digitalocean.com)
2. Acesse App Platform e crie um novo app
3. Conecte ao repositório GitHub
4. Configure:
   - Build Command: `npm install && npm run db:push`
   - Run Command: `npm run dev`
5. Adicione um banco PostgreSQL gerenciado
6. Configure variáveis de ambiente

## 📂 Estrutura do Projeto

```
.
├── client/                 # Frontend React
│   ├── src/
│   │   ├── components/    # Componentes reutilizáveis
│   │   ├── contexts/      # Context API (Auth, Theme)
│   │   ├── pages/         # Páginas da aplicação
│   │   ├── lib/           # Utilitários
│   │   └── App.tsx        # App principal
│   └── index.html
├── server/                 # Backend Node.js
│   ├── middleware/        # Middlewares (auth)
│   ├── db.ts              # Configuração do banco
│   ├── storage.ts         # Camada de dados
│   ├── routes.ts          # Rotas da API
│   └── index.ts           # Servidor Express
├── shared/                 # Código compartilhado
│   └── schema.ts          # Schemas Drizzle + Zod
└── uploads/               # Arquivos enviados
```

## 🔐 Permissões por Função

### Admin
- Acesso total ao sistema
- Criar/editar/excluir clientes, projetos, tarefas
- Gerenciar finanças
- Publicar avisos
- Visualizar todos os relatórios

### Gerente
- Criar/editar/excluir clientes e projetos
- Criar tarefas para funcionários
- Gerenciar finanças
- Visualizar relatórios

### Funcionário
- Visualizar clientes e projetos
- Marcar tarefas como concluídas
- Registrar horas trabalhadas (timesheet)
- Participar do chat
- Visualizar avisos

## 📱 Responsividade

O sistema é totalmente responsivo e funciona em:
- Desktop (1920x1080 e superior)
- Tablet (768px - 1024px)
- Mobile (375px - 767px)

## 🎨 Paleta de Cores

- **Azul Claro**: #74C0FC (Primary)
- **Azul Escuro**: #1E3A8A (Sidebar)
- **Roxo**: #7C3AED (Secondary)
- **Rosa**: #EC4899 (Accent)

## 📝 Licença

Este é um projeto desenvolvido para fins de demonstração.

## 🤝 Suporte

Para dúvidas ou suporte, entre em contato através do chat interno do sistema.
