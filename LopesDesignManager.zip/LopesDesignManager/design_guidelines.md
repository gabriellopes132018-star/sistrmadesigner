# Design Guidelines: Lopes Designer Gestão

## Design Approach

**Selected Approach:** Design System (Material Design + Custom Brand Identity)

This is a productivity-focused admin dashboard requiring consistent, efficient UI patterns. We'll adapt Material Design principles with the specified brand colors to create a modern, professional management system inspired by Notion and Figma's dashboard aesthetics.

**Core Principles:**
- **Efficiency First:** Clear information hierarchy, quick access to key functions
- **Professional Polish:** Clean, modern aesthetic suitable for business use
- **Brand Identity:** Strong visual personality through the specified color palette
- **Consistency:** Unified component library across all modules

---

## Typography System

**Font Family:** Inter (primary choice for superior readability in UI)
- Fallback: Poppins for a softer alternative

**Type Scale:**

- **Display/Hero:** 3xl to 4xl (36-48px), font-weight 700, tracking tight
- **H1 (Page Titles):** 2xl (24px), font-weight 700, used for main page headers
- **H2 (Section Headers):** xl (20px), font-weight 600, for card titles and subsections
- **H3 (Component Headers):** lg (18px), font-weight 600, for table headers, dialog titles
- **Body Large:** base (16px), font-weight 400, for primary content, form labels
- **Body Regular:** sm (14px), font-weight 400, for secondary text, descriptions
- **Small/Meta:** xs (12px), font-weight 500, for timestamps, badges, helper text

**Usage Guidelines:**
- Page titles always use H1 with subtle gradient from purple (#7C3AED) to pink (#EC4899)
- Section cards use H2 in dark blue (#1E3A8A) for light mode, light blue (#74C0FC) for dark mode
- All body text uses consistent line-height of 1.5 for readability

---

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24

**Common Patterns:**
- Component padding: p-6 (standard card padding)
- Section spacing: mb-8 or mb-12 (between major sections)
- Element gaps: gap-4 or gap-6 (for flex/grid layouts)
- Button/Input padding: px-6 py-3 (comfortable touch targets)
- Icon margins: mr-2 or ml-2 (spacing from text)

**Main Layout Structure:**

**Sidebar (Fixed Left):**
- Width: 280px (desktop), collapsible to 64px (icon-only mode)
- Mobile: Drawer overlay (full width when open)
- Background: Dark blue (#1E3A8A) in light mode, darker variant in dark mode
- Logo area: h-16 with centered logo and brand name
- Navigation items: h-12 with icon (w-5 h-5) + text, hover state with light blue (#74C0FC) accent

**Top Navbar (Fixed):**
- Height: h-16
- Background: White (light mode), dark gray (dark mode)
- Layout: Flexbox with search bar (flex-1), notification bell, user avatar dropdown
- Shadow: subtle (shadow-sm) for depth separation

**Main Content Area:**
- Margin left: ml-[280px] (desktop), ml-0 (when sidebar collapsed/mobile)
- Padding: p-6 to p-8
- Max width: Full width with internal containers using max-w-7xl for content sections
- Background: Light gray (#F9FAFB) in light mode, dark gray (#111827) in dark mode

**Grid System:**
- Dashboard cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 with gap-6
- Form layouts: Two-column for inputs (grid-cols-1 md:grid-cols-2 gap-4)
- Table layouts: Full width with horizontal scroll on mobile

---

## Color Application

**User-Specified Palette:**
- Light Blue: #74C0FC (primary actions, links, active states)
- Dark Blue: #1E3A8A (sidebar, headers, dark accents)
- Purple: #7C3AED (secondary actions, gradients)
- Pink: #EC4899 (accents, notifications, gradients)

**Semantic Usage:**

**Primary Actions:** Light blue (#74C0FC) buttons with white text
- Hover: Darken by 10%
- Active: Darken by 15%

**Secondary Actions:** Purple (#7C3AED) outlined buttons
- Hover: Light purple background with 10% opacity

**Destructive Actions:** Use pink (#EC4899) for delete/remove actions
- Hover: Darken by 10%

**Status Indicators:**
- "Não iniciado": Gray (#9CA3AF)
- "Em andamento": Light blue (#74C0FC)
- "Concluído": Green (#10B981)

**Backgrounds:**
- Light mode: White cards on #F9FAFB base
- Dark mode: #1F2937 cards on #111827 base

**Text:**
- Light mode: #1F2937 (primary), #6B7280 (secondary)
- Dark mode: #F9FAFB (primary), #9CA3AF (secondary)

**Gradients:** Apply purple-to-pink gradient (from-purple-600 to-pink-500) for:
- Page titles (text gradient)
- Feature highlights
- Chart accent fills

---

## Component Library

### Navigation

**Sidebar Menu Items:**
- Height: h-12
- Padding: px-4
- Flex layout with icon (w-5 h-5 mr-3) + text
- Active state: Light blue (#74C0FC) background with 15% opacity + border-l-4 in light blue
- Hover: Light blue background with 8% opacity
- Text: White in sidebar, weight-500

**Top Navigation:**
- Search bar: Rounded-lg input with icon prefix, min-w-[320px]
- Notification bell: Icon button with badge counter (absolute positioned circle)
- User dropdown: Avatar (w-10 h-10 rounded-full) with caret icon

### Cards & Containers

**Dashboard Cards:**
- Background: White (light), #1F2937 (dark)
- Border radius: rounded-xl
- Shadow: shadow-md with hover:shadow-lg transition
- Padding: p-6
- Header: Flex justify-between with title (H2) and action button/icon

**Stat Cards:**
- Gradient border-t-4 using brand colors (light blue, purple, pink)
- Large number: text-4xl font-bold
- Label: text-sm text-gray-500
- Icon: Positioned top-right, w-12 h-12 with 15% opacity background circle

### Forms

**Input Fields:**
- Height: h-12
- Padding: px-4
- Border: 1px solid #D1D5DB (light), #4B5563 (dark)
- Rounded: rounded-lg
- Focus: Ring-2 ring-light-blue (#74C0FC) with ring-offset-2
- Label: mb-2, font-medium, text-sm

**Textarea:**
- Min height: min-h-[120px]
- Same styling as inputs with py-3 padding

**Select Dropdowns:**
- Height: h-12
- Custom styled with chevron icon
- Options with hover:bg-gray-100 states

**File Upload:**
- Dashed border (border-2 border-dashed)
- Centered icon and text
- Drag-and-drop area: min-h-[160px]
- Active drop state: Border light blue with blue background (10% opacity)

**Buttons:**
- Primary: bg-light-blue (#74C0FC), rounded-lg, h-12, px-6, font-medium
- Secondary: Outlined with border-2 border-purple (#7C3AED), transparent background
- Destructive: bg-pink (#EC4899)
- Icon buttons: w-10 h-10, rounded-lg, centered icon
- All include subtle shadow and hover:shadow-md transition

### Data Display

**Tables:**
- Full width with min-w-full
- Header: bg-gray-50 (light), bg-gray-800 (dark), sticky top-0
- Row height: h-16
- Borders: border-b border-gray-200
- Hover: bg-gray-50 (light), bg-gray-800 (dark)
- Cell padding: px-6 py-4
- Alternating rows: subtle bg difference for better scanning

**Status Badges:**
- Rounded-full px-3 py-1
- Text: text-xs font-semibold
- Color-coded backgrounds with matching text colors
- Inline-flex with centered alignment

**Charts/Graphs:**
- Use Chart.js or Recharts library
- Brand color palette for data series (light blue, purple, pink)
- Grid lines: subtle gray (#E5E7EB)
- Tooltips: White background, shadow-lg, rounded-lg, p-3

### Modals & Dialogs

**Structure:**
- Overlay: bg-black/50 backdrop-blur-sm
- Modal: max-w-2xl, bg-white (light), bg-gray-800 (dark)
- Rounded: rounded-2xl
- Shadow: shadow-2xl
- Header: pb-4 border-b with H2 title + close button
- Body: py-6 px-6
- Footer: pt-4 border-t with action buttons (right-aligned flex)

### Chat Interface

**Chat Container:**
- Height: h-[600px] with flex-col layout
- Message list: flex-1 overflow-y-auto, p-4
- Input area: border-t, p-4

**Message Bubbles:**
- Max width: max-w-[70%]
- Padding: px-4 py-3
- Rounded: rounded-2xl
- Sent: bg-light-blue (#74C0FC), text-white, self-end
- Received: bg-gray-100 (light), bg-gray-700 (dark), self-start
- Timestamp: text-xs text-gray-500, mt-1

**Notifications/Toasts:**
- Fixed top-right positioning
- Slide-in animation from right
- Width: w-96
- Background: White with colored left border (4px)
- Shadow: shadow-xl
- Auto-dismiss after 5 seconds
- Icon + message + close button layout

---

## Dashboard Layouts

**Overview Dashboard:**
- Grid of 4 stat cards at top (grid-cols-4)
- Revenue chart below (full width, h-[400px])
- Two-column layout below: Recent projects (left) + Team activity (right)

**Project List View:**
- Filter bar at top (search + status dropdown + date picker)
- Table with columns: Project name, Client, Status, Value, Deadline, Responsible, Actions
- Pagination at bottom

**Financial Dashboard:**
- Three stat cards: Total revenue, Total expenses, Net profit
- Dual-line chart showing income vs expenses over time
- Transaction table below with search and date filters

**Timesheet View:**
- Calendar grid showing days of month
- Each day cell shows total hours logged
- Sidebar with task list and time entry form

---

## Responsive Behavior

**Breakpoints:**
- Mobile: < 768px (md)
- Tablet: 768px - 1024px
- Desktop: > 1024px

**Mobile Adaptations:**
- Sidebar becomes drawer (overlay)
- Stat cards stack to single column
- Tables scroll horizontally or card view
- Navigation menu: Hamburger icon reveals drawer
- Reduce padding: p-4 instead of p-6

**Tablet:**
- Sidebar visible but collapsible
- Grid cards: 2 columns
- Full table functionality maintained

---

## Dark Mode Implementation

Use Tailwind's dark: prefix for all color variations:
- Toggle switch in top navbar (moon/sun icon)
- Persist preference in localStorage
- Smooth transition: transition-colors duration-200

**Key Differences:**
- Background: #111827 base, #1F2937 cards
- Text: #F9FAFB primary, #9CA3AF secondary
- Borders: #374151
- Sidebar: Even darker variant of dark blue
- Maintain brand color vibrancy in both modes

---

## Animations

**Use Sparingly - Only for:**
- Page transitions: Fade-in with slight upward movement (20px)
- Modal appearances: Scale from 95% to 100% with fade
- Notification toasts: Slide-in from right
- Loading states: Subtle pulse on skeleton screens

**Durations:** Keep all transitions to 200-300ms for snappiness

---

## Accessibility

- All interactive elements: min-height 44px (touch targets)
- Focus states: Always visible with ring-2
- Color contrast: WCAG AA compliant minimum
- Form labels: Always associated with inputs
- Icon buttons: Include aria-label
- Keyboard navigation: Full support with logical tab order
- Screen reader: Semantic HTML with proper ARIA labels